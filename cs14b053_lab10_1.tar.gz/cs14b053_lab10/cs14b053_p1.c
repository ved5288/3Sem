#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
#include<string.h>



bool dict(char* s){
	char* dictionary[] = {"this","is","a","good","test","ago","me","if","you","can","and","how","do","write","such","a","program","print","some","permit","control","over","different",
"functions","the","airport","moving","away","from","dependence","bad","code","poetry","go","i","am","poet","once","upon","time","there","hermit","the", "bowler", "delivers", "ball", "to", "batsman", "who", "attempts", "to", "hit", "ball", "with", "his", "bat", "away", "from","fielders", "so", "he", "can", "run", "to","other", "end", "of", "pitch", "and", "score","run", "each", "batsman", "continues", "batting", "until", "he","is", "out","earliest", "written", "evidence", "of", "game", "cricket", "may", "date", "back", "to", "france", "in", "letter", "written", "to", "king", "louis", "XI","as", "was", "reported", "to", "press", "not", "only", "are","buses", "somewhat", "inconvenient", "and", "uncomfortable"};
	
 int size = sizeof(dictionary)/sizeof(dictionary[0]);
   
int i;
 for (i = 0; i < size; i++)
	if(strcmp(s,dictionary[i])==0){
		return true;	
	}
	
	
	return false;
}

int main(int argc, char* argv[])
{

	FILE *ifp,*ofp;
	ifp=fopen(argv[1],"r");
	ofp=fopen(argv[2],"w");

	int t,i,n,j,p,curr_value,q;

	fscanf(ifp,"%d",&t);
	for(p=0;p<t;p++)
	{
		char s[101];
		fscanf(ifp,"%s",s);
		n=strlen(s);
		int valid[n],curr_index;
		
		for(i=0;i<n;i++)
			valid[i]=0;

		for(i=0;i<n;i++)
		{
			char temp[i+2];

			strncpy(temp,s,i+1);
			temp[i+1]='\0';
			if(dict(temp)==true)
				valid[i]=1;
			
			else
			{
			
				for(j=0;j<i;j++)
				{
					char temp1[n-j-1];
					strncpy(temp1,&temp[j+1],n-j-1);
					temp1[n-j-1]='\0';
					if(valid[j]!=0)
						if(dict(temp1)==true)
							valid[i]=j;
				}	
			
			}	
		}
		

		if(valid[n-1]==0)
			fprintf(ofp,"Invalid string\n"); 	// changed here
		else
		{
			curr_value=n-1;
			while(valid[curr_value]!=1)
			{
				q=valid[curr_value];
				valid[curr_value]=-1;
				curr_value=q;
			}
			valid[curr_value]=-1;
			for(i=0;i<n;i++)
				if(valid[i]!=-1)
					valid[i]=0;
		

			for(i=0;i<n;i++)
				if(valid[i]==-1)
					fprintf(ofp,"%c ",s[i]);
				else
					fprintf(ofp,"%c",s[i]);
			fprintf(ofp,"\n");
		}
	
	}

	
return 0;	
}

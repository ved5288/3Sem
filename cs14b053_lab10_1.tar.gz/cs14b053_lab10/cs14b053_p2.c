#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main(int argc,char* argv[])
{
	FILE *ifp,*ofp;
	ifp=fopen(argv[1],"r");
	ofp=fopen(argv[2],"w");

	int i,j,t,n,p,q,k;
	char m;

	fscanf(ifp,"%d",&t);
	
	int T[t];

	for(i=0;i<t;i++)
	{

		fscanf(ifp,"%d",&n);
		
		int B[n+1];
		for(j=0;j<=n;j++)
		fscanf(ifp,"%d",&B[j]);
		n=n+1;
		

		char s[1000];
	
		int min,max,sum;
		min=0;
		max=0;
		for(j=0;j<n;j++)
		{
			if(B[j]<min)
				min=B[j];
			if(B[j]>max)
				max=B[j];
		}
			
		p=max-min+1;
		q=n-1;
		
		int matrix[p][q];

		for(j=0;j<p;j++)
			for(k=0;k<q;k++)
				matrix[j][k]=0;

		matrix[-min][0]=1;
		matrix[B[0]-min][0]=1;
		
		for(k=1;k<q;k++)
			for(j=0;j<p;j++)
				if(matrix[j][k-1]==1)
				{
					
					matrix[j][k]=1;
					if(j+B[k]<p)
						matrix[j+B[k]][k]=1;
				}
		sum=B[n-1];
		int count=0;
		if(matrix[sum-min][q-1]==1)
		{
		while(sum!=0)
		{
			for(j=0;j<q;j++)
				if(matrix[sum-min][j]==1)
					break;
			if(count==0)
			fprintf(ofp,"%d",B[j]);
			else
			fprintf(ofp,", %d",B[j]);
			count++;
			sum=sum-B[j];
		}
		fprintf(ofp,"\n");
		}
		else
		fprintf(ofp,"No subset found\n");
		
		
				
	}
}

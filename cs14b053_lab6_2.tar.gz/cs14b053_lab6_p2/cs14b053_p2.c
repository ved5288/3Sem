#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int StringCompare(char *s1, char* s2, char* OrderString)
{
	int n1,n2,p,i,k=0,j,l,n;
	n=strlen(OrderString);
	n1=strlen(s1);
	n2=strlen(s2);
	if(n1>n2) 
		p=n2;
	else 	p=n1;
	for(i=0;i<p;i++)
		if(s1[i]!=s2[i])
		{
			k=1;
			break;
		}
	if(k==1)
	{
		for(j=0;j<n;j++)
			if(OrderString[j]==s1[i])
				break;
		for(l=0;l<n;l++)
			if(OrderString[l]==s2[i])
				break;
	return j-l;
	}
	if(n1==n2)
		return 0;
	if(n1>n2)
		return s1[p]-'a'+1;
	return -s2[p]+'a'-1;
}

int main(int argc, char* argv[])
{
	char s1[1000],s2[1000],OrderString[26];
	int i,n,j,l,width,k,p;
	FILE *ifp,*ofp;
	ifp=fopen(argv[1],"r");
	ofp=fopen(argv[2],"w");
	fscanf(ifp,"%s",OrderString);
	fscanf(ifp,"%d",&n);
	char A[n][1000];
	for(i=0;i<n;i++)
	{	
		fscanf(ifp,"%s",A[i]);
	}		
	
	for(width=1;width<n;width*=2)
	{
		for(i=0;i<n;i+=2*width)
		{
			p=0;
			k=0;
			for(j=0;j<width;j++)
			{
				if(p==1)
					break;
				for(;k<width;k++)
					if(n<=i+width+j)
					{
						p=1;
						break;
					}
					else if(StringCompare(A[i+width+j],A[i+k],OrderString)<=0)
					{
						char B[1000];
						strcpy(B,A[i+width+j]);
						for(l=i+width+j;l>i+k;l--)
						{
							strcpy(A[l],A[l-1]);
						}
						strcpy(A[i+k],B);
						k--;
					}
			}						
		}	
	
	}
	for(i=0;i<n;i++)
		fprintf(ofp,"%s\n",A[i]);
	fclose(ifp);
	fclose(ofp);	
return 0;
}



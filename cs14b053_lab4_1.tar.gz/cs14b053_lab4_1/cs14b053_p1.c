#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdbool.h>

struct SNode
{
	char data;
	struct SNode* next;
};

void Push(struct SNode** top, char ch)
{
	struct SNode* current_stack = *top;
	// current_stack is the stack to work upon

	//create a SNode
	struct SNode* temp=(struct SNode*)malloc(sizeof(struct SNode));
	temp->data=ch;
	temp->next=current_stack;

	//reassign the value to the stack *top*
	*top=temp;
}

void print(struct SNode* top)
{
	if(top==NULL)
	{
		printf("0\n");
		return;	
	}
	struct SNode* temp=top;
	while(temp->next!=NULL)
	{
		printf("%c ",temp->data);
		temp=temp->next;
	}
	printf("%c\n",temp->data);
}

char Pop(struct SNode** top)
{
	//assumed that the Stack is not empty
	struct SNode* current_stack = *top;

	if(current_stack==NULL)
	{
		printf("The Stack is empty\n");
		return;
	}

	char b;
	b=current_stack->data;
	struct SNode* temp;
	temp=current_stack;
	current_stack=current_stack->next;
	*top=current_stack;
	free(temp);
	return b;
}

char Top(struct SNode* top)
{
	
	if(top==NULL)
	{
		printf("The stack is empty\n");
		return;
	}
	return top->data;
}

bool isEmpty(struct SNode* top)
{
	if(top==NULL) return true;
	return false;
}

int main()
{
	struct SNode* top=(struct SNode*)malloc(sizeof(struct SNode));
	top=NULL;
	print(top);
	printf("The top element is %c\n\n",Top(top));
	Push(&top,65);
	print(top);
	printf("The top element is %c\n\n",Top(top));
	Push(&top,'a');
	print(top);
	printf("The top element is %c\n\n",Top(top));
	Push(&top,'b');
	print(top);
	printf("The top element is %c\n\n",Top(top));
	printf("Deleted item is %c\n",Pop(&top));
	print(top);
	printf("The top element is %c\n\n",Top(top));
	printf("Deleted item is %c\n",Pop(&top));
	print(top);
	printf("The top element is %c\n\n",Top(top));	
	printf("Deleted item is %c\n",Pop(&top));
	print(top);
	printf("The top element is %c\n\n",Top(top));	
	printf("Deleted item is %c\n",Pop(&top));
	print(top);
	printf("The top element is %c\n\n",Top(top));	
return 0;
}

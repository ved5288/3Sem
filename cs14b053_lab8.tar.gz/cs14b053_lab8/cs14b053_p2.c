#include<stdio.h>
#include<stdlib.h>

int vedant=0;
int count=0;


void print(int* arr, int n)
{
	int i,j;
	for(i=0;i<n+2;i++)
	{
		for(j=0;j<n+2;j++)
			printf("%d ",*((arr+i*(n+2))+j));
		printf("\n");
	}
	printf("\n");	
}


int isMovePossible(char player,int position,int * arr,int n)
{
	// returns 1 if the move is possible
	// returns 0 if the move is not possible
	// returns -1 if the code is wrong

	int i;

	if(player=='1')
	{
		for(i=0;i<n+2;i++)
			if(*((arr+i*(n+2))+position)==1)
				break;
		if(i==n+1)
			return 0;
		if(*((arr+(i+1)*(n+2))+position)==2)
			if(*((arr+(i+2)*(n+2))+position)==2)
				return 0;
		return 1;
	}
	
	else if(player=='2')
	{
		for(i=0;i<n+2;i++)
			if(*((arr+position*(n+2))+i)==2)
				break;
		if(i==n+1)
			return 0;
		if(*((arr+position*(n+2))+i+1)==1)
			if(*((arr+position*(n+2))+i+2)==1)
				return 0;
		return 1;
	}
return -1;
}

void move_player(int* arr, int n, char player, int position)
{
	int i;	
	
	if(player=='1')
	{
		for(i=0;i<n+1;i++)
			if(*((arr+i*(n+2))+position)==1)
				break;

		if(*((arr+(i+1)*(n+2))+position)==0)
		{
			*((arr+i*(n+2))+position)=0;
			*((arr+(i+1)*(n+2))+position)=1;
		}
		else
		{
			*((arr+i*(n+2))+position)=0;
			*((arr+(i+2)*(n+2))+position)=1;
		}
	}
	else
	{
		for(i=0;i<n+1;i++)
			if(*((arr+position*(n+2))+i)==2)
				break;

		if(*((arr+position*(n+2))+i+1)==0)
		{
			*((arr+position*(n+2))+i)=0;
			*((arr+position*(n+2))+i+1)=2;
		}
		else
		{
			*((arr+position*(n+2))+i)=0;
			*((arr+position*(n+2))+i+2)=2;
		}
	}
}

void move_the_player_back(char player,int position,int* arr,int n)
{	int i;	
	
	if(player=='1')
	{
		for(i=0;i<n+2;i++)
			if(*((arr+i*(n+2))+position)==1)
				break;
		if(*((arr+(i-1)*(n+2))+position)==0)
		{
			*((arr+i*(n+2))+position)=0;
			*((arr+(i-1)*(n+2))+position)=1;
		}
		else
		{
			*((arr+i*(n+2))+position)=0;
			*((arr+(i-2)*(n+2))+position)=1;
		}
	}
	else
	{
		for(i=0;i<n+2;i++)
			if(*((arr+position*(n+2))+i)==2)
				break;
		if(*((arr+position*(n+2))+i-1)==0)
		{
			*((arr+position*(n+2))+i)=0;
			*((arr+position*(n+2))+i-1)=2;
		}
		else
		{
			*((arr+position*(n+2))+i)=0;
			*((arr+position*(n+2))+i-2)=2;
		}
	}
}



int IsThereAWinningStrategy(int * arr, char player,int n,char* file_name)
{
	FILE *ofp;
	int i,p,q,l,flag,j,row,col;
	char opp_player;
	
	if(player=='1')
		opp_player='2';
	else
		opp_player='1';

	if(player=='1')
	{
		q=1;
		for(i=1;i<=n;i++)
			if(*((arr+i*(n+2))+n+1)==0)
			{
				q=0;
				break;
			}
		if(q==1)
			return 0;
		else
		{
			p=0;
			for(i=1;i<=n;i++)
				if(*((arr+(n+1)*(n+2))+i)==0)
				{
					p=1;
					break;		
				}
			if(p==0)
				return 1;	
		}
	}

	else
	{
		q=1;
		for(i=1;i<=n;i++)
			if(*((arr+(n+1)*(n+2))+i)==0)
			{
				q=0;
				break;
			}
		if(q==1)
			return 0;
		else
		{
			p=0;
			for(i=1;i<=n;i++)
				if(*((arr+i*(n+2))+n+1)==0)
				{
					p=1;
					break;		
				}
			if(p==0)
				return 1;	
		}
	}
	
	p=0;
	for(i=1;i<=n;i++)
	{
		p=isMovePossible(player,i,arr,n);
		//move player
		if(p==1)
		{		
			move_player(arr,n,player,i);
			//print(arr,n);
			q=1;
			flag=0;
			for(j=1;j<=n;j++)
			{
				l=isMovePossible(opp_player,j,arr,n);
				if(l==1)
				{
					flag=1;
					move_player(arr,n,opp_player,j);
					//print(arr,n);
					q=IsThereAWinningStrategy(arr,player,n,file_name);
					move_the_player_back(opp_player,j,arr,n);
					//print(arr,n);
					if(q==0)
						break;		
				}				
			}
			
			if(flag==0)
			{
				if(IsThereAWinningStrategy(arr,player,n,file_name)>0)
				{
					move_the_player_back(player,i,arr,n);
					return i;
				}
				else
				{
					move_the_player_back(player,i,arr,n);
				}
			}
			else
			{
				
				if(q>0)
				{
					
					ofp=fopen(file_name,"w");
					for(row=0;row<n+2;row++)
					{					
						for(col=0;col<n+2;col++)
							fprintf(ofp,"%d ",*((arr+row*(n+2))+col));
						fprintf(ofp,"\n");
					}
					fclose(ofp);
					printf("%d\n",++count);
					print(arr,n);
					move_the_player_back(player,i,arr,n);
					
					return i;
				}
				else
					move_the_player_back(player,i,arr,n);
			}
		}
	}
	if(p==0)
	{
		q=1;
		flag=0;
		for(j=1;j<=n;j++)
		{
			l=isMovePossible(opp_player,j,arr,n);
			if(l==1)
			{
				flag=1;
				move_player(arr,n,opp_player,j);
				//print(arr,n);
				q=IsThereAWinningStrategy(arr,player,n,file_name);
				move_the_player_back(opp_player,j,arr,n);
				//print(arr,n);
				if(q==0)
					break;		
			}				
		}	
		if(flag==0)
			return 0;
		else
		{
			if(q>0)	
				return 1;
		}
	}
}

int main(int agrc,char* argv[])
{
	int n,i,j;
	int a;
	char temp[2];

	FILE *ifp;
	ifp = fopen(argv[1],"r");
	fscanf(ifp,"%d",&n);

	int matrix[n+2][n+2];

	//initialisation
	for(i=0;i<n+2;i++)
	for(j=0;j<n+2;j++)
	matrix[i][j]=0;

	for(j=1;j<=n;j++)
	{
		fscanf(ifp,"%d,",&a);
		matrix[a][j]=1;
	}

	for(i=1;i<=n;i++)
	{
		fscanf(ifp,"%d,",&a);
		matrix[i][a]=2;
	}

	for(i=0;i<n+2;i++)
	{
		for(j=0;j<n+2;j++)
		printf("%d ",matrix[i][j]);
		printf("\n");
	}
	printf("\n");

	fscanf(ifp,"\n%c%c",&temp[0],&temp[1]);

	//findout a winning strategy for the player temp[1]
	a=IsThereAWinningStrategy((int*)matrix,temp[1],n,argv[2]);
	printf("%d\n",a);

}

#include<stdio.h>
#include<stdlib.h>

// SUDOKU SOLVER
int flag=0;
//int last_row,last_col;
int input[9][9];
FILE * ofp;

void print(char* arr,char* file_name)
{
	int i,j;
	ofp = fopen(file_name,"w");
	for(i=0;i<9;i++)
	{	
		for(j=0;j<9;j++)
			fprintf(ofp,"%c ",*((arr+i*9)+j));
		fprintf(ofp,"\n");
	}
	//printf("\n");
}

void solve_sudoku(char *arr,int row,int col,char *order,int index,char * file_name)
{
	int i,j,marker,counter,r,c,l,wow,curr_row,curr_col,last_row,last_col,p;
	
	if(flag==1)
		return;	

	if(row>=10)
	{
		flag=1;
		print(arr,file_name);
		return;	
	}
	
	marker=0;
	if(*((arr+row*9)+col)!='-')
		marker=1;

	if(marker==0)
	{
		wow=0;
		for(i=index;i<9;i++)
		{
			counter=1;
			//check in the row
			for(j=0;j<9;j++)
				if(j!=col)
				{
					if(*((arr+row*9)+j)==order[i])
						counter=0;
				}

			if(counter==1)
			//check in the column
			for(j=0;j<9;j++)
				if(j!=row)
				{
					if(*((arr+j*9)+col)==order[i])
						counter=0;	
				}
	
			if(counter==1)
			{
			//check in the box
				r=(row/3)*3;
				c=(col/3)*3;
				for(j=r;j<r+3;j++)
				for(l=c;l<c+3;l++)
					{
						if(*((arr+j*9)+l)==order[i])
							counter=0;
					}
			}
	
			if(counter==1)
			{
				*((arr+row*9)+col)=order[i];
				//last_row=row;
				//last_col=col;
				//printf("%d %d %c\n",row,col,order[i]);
				//print(arr);

				wow=1;
				
				if(col==8)
					solve_sudoku(arr,row+1,0,order,0,file_name);				
				else
					solve_sudoku(arr,row,col+1,order,0,file_name);
			}	
			
			
		}

		if(wow==0)
		{
			curr_row=0;
			curr_col=0;
			for(i=0;i<9;i++)
			for(j=0;j<9;j++)
			{
				if(input[i][j]=='-')
				{
					last_row=curr_row;
					last_col=curr_col;
					curr_row=i;
					curr_col=j;
				}
				if(row==curr_row&&col==curr_col)
				{
					for(p=0;p<9;p++)
						if(*((arr+last_row*9)+last_col)==order[p])
							break;
					if(input[last_row][last_col]=='-')
					{
						*((arr+last_row*9)+last_col)='-';
						solve_sudoku(arr,last_row,last_col,order,p+1,file_name);
					}
					else
					{
						ofp = fopen(file_name,"w");
						flag=1;
						fprintf(ofp,"No Solution\n");
						return ;
					}
				}
			}
		}
	}

	else
	{
		if(col==8)
			solve_sudoku(arr,row+1,0,order,0,file_name);
			
		else
			solve_sudoku(arr,row,col+1,order,0,file_name);
	}				
}

int main(int argc, char* argv[])
{
	FILE *ifp;
	ifp=fopen(argv[1],"r");
	//ofp=fopen(argv[2],"w");

	char matrix[9][9];
	char order[9];
	int i,j;

	char s[17];
	fscanf(ifp,"%s",s);
	for(i=0;i<9;i++)
		order[i]=s[2*i];

	for(i=0;i<9;i++)
	{
		fscanf(ifp,"%s",s);
		for(j=0;j<9;j++)
		{
			matrix[i][j]=s[2*j];
			input[i][j]=s[2*j];
		}
	}

	solve_sudoku((char*)matrix,0,0,order,0,argv[2]);
	if(flag==0)
		printf("No Answer\n");
// order is the input word string
// matrix is the problem statement


return 0;
}

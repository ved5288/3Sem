#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"cs14b053_p2.h"



int A[10000];
int B[10000];
char C[10000];

void insert(struct node* head,int n)
{
	int i,k=0,p;

	//terminating case
	for(i=0;i<n;i++)
	{
		if(A[i]==head->data)
		{
			k=1;
			break;
		}
	}
	if(k==0)
		return ;	


	for(i=0;i<n;i++)
	{
		if(A[i]==head->data)
			{
				struct node* temp1;
				temp1 = (struct node*)malloc(sizeof(struct node*));
				if(C[i]=='L')	
				{
					temp1->data=B[i];
					temp1->left=NULL;
					temp1->right=NULL;
					head->left=temp1;
					insert(head->left,n);
				}
				
				if(C[i]=='R')
				{ 
					temp1->data=B[i];
					temp1->left=NULL;
					temp1->right=NULL;
					head->right=temp1;
					insert(head->right,n);
				}
			}
			
	}
}

struct node* create_tree(char* file_name)
{
	int n,i,p,j,k;
	struct node* tree;
	tree = (struct node*)malloc(sizeof(struct node*));
	FILE * ifp;
	ifp=fopen(file_name,"r");

	//take input
	fscanf(ifp,"%d",&n);

	//n-1 edges
	if(n==0)
		return tree;

	for(i=0;i<n-1;i++)
		fscanf(ifp,"%d %d %c",&A[i],&B[i],&C[i]);
	
	for(i=0;i<n-1;i++)
	{
		k=0;
		for(j=0;j<n-1;j++)
		{
			if(A[i]==B[j])
				{
					k=1;
					break;
				}
		}
		if(k==0)
		{
			break;		
		}
	}
	tree->data=A[i];
	tree->left = NULL;
	tree->right= NULL;
	//printf("%d\n",tree->data);
	insert(tree,n-1);
	return tree;	
}

int main(int argc, char* argv[])
{
	struct node* tree;
	tree=create_tree(argv[1]);
	postorder(tree); 
	printf("\n");
	preorder(tree);
	printf("\n");
	inorder(tree);
	printf("\n");
return 0;
}



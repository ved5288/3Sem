#include<stdio.h>
#include<stdlib.h>

struct node {
int data;
struct node* left;
struct node* right;
};

void preorder(struct node* curr)
{
	if(curr==NULL)
		return;
	printf("%d ",curr->data);
	preorder(curr->left);
	preorder(curr->right);
}

void postorder(struct node* curr)
{
	if(curr==NULL)
		return;
	postorder(curr->left);
	postorder(curr->right);
	printf("%d ",curr->data);
}

void inorder(struct node* curr)
{
	if(curr==NULL)
		return;
	inorder(curr->left);
	printf("%d ",curr->data);
	inorder(curr->right);
}


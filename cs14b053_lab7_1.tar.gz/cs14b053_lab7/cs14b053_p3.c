#include<stdio.h>
#include<stdlib.h>

struct node {
int data;
struct node* left;
struct node* right;
};



int input1[10000];
int input2[10000];
char input3[10000];
int A[10000];
int B[10000];
char C[10000];


int takeinput(char* file_name)
{
	int n,i;
	FILE * ifp;
	ifp=fopen(file_name,"r");

	//take input
	fscanf(ifp,"%d",&n);

	for(i=0;i<n-1;i++)
		fscanf(ifp,"%d %d %c",&input1[i],&input2[i],&input3[i]);
	
return n;
}

void insert(struct node* head,int n)
{
	int i,k=0,p;

	//terminating case
	for(i=0;i<n;i++)
	{
		if(A[i]==head->data)
		{
			k=1;
			break;
		}
	}
	if(k==0)
		return ;	


	for(i=0;i<n;i++)
	{
		if(A[i]==head->data)
			{
				struct node* temp1;
				temp1 = (struct node*)malloc(sizeof(struct node*));
				if(C[i]=='L')	
				{
					temp1->data=B[i];
					temp1->left=NULL;
					temp1->right=NULL;
					head->left=temp1;
					insert(head->left,n);
				}
				
				if(C[i]=='R')
				{ 
					temp1->data=B[i];
					temp1->left=NULL;
					temp1->right=NULL;
					head->right=temp1;
					insert(head->right,n);
				}
			}
			
	}
}


struct node* create_tree(char* file_name)
{
	int n,i,p,j,k;
	struct node* tree;
	tree = (struct node*)malloc(sizeof(struct node*));
	FILE * ifp;
	ifp=fopen(file_name,"r");

	//take input
	fscanf(ifp,"%d",&n);

	//n-1 edges
	if(n==0)
		return tree;

	for(i=0;i<n-1;i++)
		fscanf(ifp,"%d %d %c",&A[i],&B[i],&C[i]);
	
	for(i=0;i<n-1;i++)
	{
		k=0;
		for(j=0;j<n-1;j++)
		{
			if(A[i]==B[j])
				{
					k=1;
					break;
				}
		}
		if(k==0)
		{
			break;		
		}
	}
	tree->data=A[i];
	tree->left = NULL;
	tree->right= NULL;
	//printf("%d\n",tree->data);
	insert(tree,n-1);
	return tree;	
}


int fill_leaves(struct node* head, struct node ** D,int k)
{
	if(head->left==NULL&&head->right==NULL)
	{
		D[k]=head;
		return k+1;
	}

	if(head->left!=NULL&&head->right!=NULL)
		return fill_leaves(head->right,D,fill_leaves(head->left,D,k));
	
	if(head->left==NULL)
		return fill_leaves(head->right,D,k);

return fill_leaves(head->left,D,k);	
}


int main(int argc,char* argv[])
{
	struct node* tree;
	tree=create_tree(argv[1]);
	int n,i,j,k,count;
	n=takeinput(argv[1]);

	//counting the number of leaves
	count=0;
	for(i=0;i<n-1;i++)
	{	
		for(j=0;j<n-1;j++)
		{
			k=0;
			if(input2[i]==input1[j])
			{			
				k=1;
				break;
			}
		}
		if(k==0)
			count++;
	}
	if(tree->left==NULL||tree->right==NULL)
		count+=1;
		

	struct node* D[count];
	struct chain* E[count];
	k=0;
	if(tree->left==NULL||tree->right==NULL)
	{
		D[k]=tree;
		k++;
	}

	i=fill_leaves(tree,D,k);
	

	int matrix[count][n];
	int p,root;
	//find the root
	for(i=0;i<n-1;i++)
	{
		for(j=0;j<n-1;j++)
		{
			if(input1[i]==input2[j])
				{
					k=1;
					break;
				}
		}	
		if(k==0)
		{
			break;		
		}
	}
	root = input1[i];

	for(i=0;i<count;i++)
	{
		matrix[i][0]=D[i]->data;
		j=1;
		do
		{
			for(p=0;p<n-1;p++)
				if(input2[p]==matrix[i][j-1])
					matrix[i][j]=input1[p];
			j++;
		}
		while(matrix[i][j-1]!=root);
	}
	
	
	

	int width[count][count],r,l,m,q;
	q=n;
	for(i=0;i<count;i++)
	for(j=0;j<count;j++)
		{
			for(p=0;p<count;p++)
				if(matrix[p][0]==D[i]->data)
					break;
			for(k=0;k<count;k++)
				if(matrix[k][0]==D[j]->data)
					break;
			for(r=0;r<n;r++)
			{
			m=0;	
			for(l=0;l<n;l++)
				{if(matrix[k][l]==root)
					q=l;
				if(l>q)
					break;
				else if(matrix[p][r]==matrix[k][l])
					{
						m=1;
						break;
					}}
			if(m==1)
				break;
			}
			q=n;
			width[i][j]=r+l;						
		}
	int max;
	max=width[0][0];
		for(i=0;i<count;i++)
	{
		for(j=0;j<count;j++)
		if(width[i][j]>max)
			max=width[i][j];
	}
	printf("%d\n",max);
}


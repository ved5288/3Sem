#include<stdio.h>
#include<stdlib.h>

struct node
{
	int majority;
	int count;
};

int isequal(int e1,int e2)
{
	if(e1%5==e2%5)
		return 1;
	return 0;
}

struct node majority(int* A,int n)
{
	struct node answer;
	struct node m1,m2;
	int i,count;
	int array1[n/2],array2[n/2];

	if(n==1)
	{
		answer.majority=A[0];
		answer.count=1;
		return answer;
	}
	
	for(i=0;i<n/2;i++)
	{
		array1[i]=A[i];
		array2[i]=A[n/2+i];
	}
	
	m1=majority(array1,n/2);
	m2=majority(array2,n/2);

	if(m1.count==0&&m2.count==0)
	{
		answer.majority=-1;
		answer.count=0;
		return answer;
	}

	if(isequal(m1.majority,m2.majority)==1)
	{
		answer.majority=m1.majority;
		answer.count=m1.count+m2.count;
		return answer;
	}

	if(m1.count>m2.count)
	{
		count=0;
		for(i=0;i<n/2;i++)
			if(isequal(m1.majority,array2[i])==1)
				count++;
		if(m1.count+count>n/2)
		{
			answer.majority=m1.majority;
			answer.count=m1.count+count;
		}	
		else
		{
			answer.majority=-1;
			answer.count=0;
		}	
		return answer;
	}

	if(m2.count>m1.count)
	{
		count=0;
		for(i=0;i<n/2;i++)
			if(isequal(m2.majority,array1[i])==1)
				count++;
		if(m2.count+count>n/2)
		{
			answer.majority=m2.majority;
			answer.count=m2.count+count;
		}
		else
		{
			answer.majority=-1;
			answer.count=0;
		}	
		return answer;
	}	
	
}

int main(int argc,char* argv[])
{
	FILE *ifp,*ofp;
	ifp=fopen(argv[1],"r");
	ofp=fopen(argv[2],"w");
	
	int n,i;

	fscanf(ifp,"%d",&n);

	int A[n/2],B[n/2];

	for(i=0;i<n;i++)
		fscanf(ifp,"%d",&A[i]);

	struct node answer;
	answer=majority(A,n);
	if(answer.count==0)
		fprintf(ofp,"No majority element\n");
	else
		fprintf(ofp,"%d\n",answer.majority);
	fclose(ifp);
	fclose(ofp);
return 0;
}



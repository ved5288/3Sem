#include<stdio.h>
#include<stdlib.h>

float find_median(int* A,int* B,int n)
{
	int p;
	float m1,m2;

	if(n%2==0)
	{
		p=n/2;
		m1=(A[n/2-1]+A[n/2])/2.0;
		m2=(B[n/2-1]+B[n/2])/2.0;
		
	}
	else
	{
		m1=(float)A[n/2];
		m2=(float)B[n/2];
		p=n/2+1;
	}
	
	if(m1==m2)
		return m1;

	if(n==1)
		return (A[0]+B[0])/2.0;

	if(n==2)
		if(A[1]>B[1])
			if(A[0]>B[0])
				return (A[0]+B[1])/2.0;
			else
				return (B[0]+B[1])/2.0;
		else
			if(A[0]>B[0])
				return (A[0]+A[1])/2.0;
			else			
				return (B[0]+A[1])/2.0;

	int *array1,*array2;

	if(m1<m2)
	{
		array1=&A[n/2];
		array2=&B[0];	
	}
	
	else
	{
		array1=&B[n/2];
		array2=&A[0];
	}

	return find_median(array1,array2,p);
}

int main(int argc, char*argv[])
{
	FILE *ifp,*ofp;
	ifp=fopen(argv[1],"r");
	ofp=fopen(argv[2],"w");

	int n,i;
	
	fscanf(ifp,"%d",&n);

	int A[n],B[n];

	for(i=0;i<n;i++)
		fscanf(ifp,"%d,",&A[i]);
	for(i=0;i<n;i++)
		fscanf(ifp,"%d,",&B[i]);

	fprintf(ofp,"%0.1f\n",find_median(A,B,n));
	fclose(ifp);
	fclose(ofp);
return 0;
}

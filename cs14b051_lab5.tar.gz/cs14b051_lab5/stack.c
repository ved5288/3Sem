#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
#include"stack.h"

void Push(struct SNode** top,char ch)
{
  struct SNode* temp1;
  (temp1)=(struct SNode*)malloc(sizeof(struct SNode));
  (temp1)->data=ch;
  temp1->next=(*top);
  *top=temp1;
}

char Pop(struct SNode** top)
{
  char m;
struct SNode *luck;
luck=(struct SNode *)malloc(1*sizeof(struct SNode));
luck=*top;
struct SNode *top1;
  top1=(struct SNode *)malloc(1*sizeof(struct SNode));
  top1=luck->next;
 m=luck->data;
 free(luck);
 luck=top1;
 *top=luck;
  return m;
}

char Top(struct SNode* top)
{
  return top->data;
}

bool IsEmpty(struct SNode* top)
{
  if(top == NULL)
    {
      return true;
    }
  else
    return false;
}




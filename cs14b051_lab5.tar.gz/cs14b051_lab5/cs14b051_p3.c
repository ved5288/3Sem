#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"stack.h"

struct SNode* top=NULL;
struct position
{
  int x;
  int y;
};

struct position FinalPosition(char* s)
{
  int i,n,k=1,m,j;
  n=strlen(s);
  struct position luck;
  luck.x=0;
  luck.y=0;
  for(i=0;i<n;i++)
    {
	  if(s[i]=='R'||s[i]=='L'||s[i]=='U'||s[i]=='D')
	    {
	      Push(&top,s[i]);
	    }
	  else if(s[i]=='B')
	    {
	      m=0;
	      while(isdigit(s[i+1]))
		{
		  m=m*10+(s[i+1]-48);
		  i++;
		}
	      for(j=0;j<m;j++)
		{
		  Pop(&top);
		}
	      i--;
	    }
    }
	  while(IsEmpty(top) ==0)
	    {

	      if(Top(top)=='R')
		{
		  luck.x=luck.x+1;
		}
	      else if(Top(top)=='U')
		{
		  luck.y=luck.y+1;
		}
	      else if(Top(top)=='L')
		{
		  luck.x=luck.x-1;
		}
	      else if(Top(top)=='D')
		{
		  luck.y=luck.y-1;
		}
	      Pop(&top);
	    }
	  printf("%d %d",luck.x,luck.y);
  return luck;
}

int main()
{
  char* str;
  str=(char *)malloc(sizeof(char));
  scanf("%s",str);
  FinalPosition(str);
  return 0;
}

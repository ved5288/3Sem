#include"stack.h"
#include<string.h>
#include<stdbool.h>
#include<stdlib.h>
#include<stdio.h>

struct SNode* top= NULL;
bool IsBalancedParanthesis(char* s)
{
  int i,n;
  n=strlen(s);
 // printf("%d %c ",n,s[1]);
  if(n%2==0)
    {
      Push(&top,s[0]);
      for(i=1;i<n;i++)
	{
	   if(top!=NULL)
	    {
	      if((Top(top)==(s[i]-1)) || (Top(top)==s[i]-2))
		{
		  Pop(&top);
		}
		else
		Push(&top,s[i]);
	    }
	    else
	    Push(&top,s[i]);
	}
      if(IsEmpty(top)==1)
	return true;
      else
	return false;
    }
  else
    {
      return false;
    }
}

int main()
{
  char* str;
  str=(char*)malloc(1*sizeof(char));
  scanf("%s",str);
  // printf("%s",str);
  if(IsBalancedParanthesis(str)==0)
    {
      printf("false\n");
    }
  else
      printf("true\n");
  return 0;
}
	     

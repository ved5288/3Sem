#ifndef HEADER_FILE
#define HEADER_FILE

struct SNode
{
	char data;
	struct SNode* next;
};

void Push(struct SNode**,char);
char Pop(struct SNode**);
char Top(struct SNode*);
bool isEmpty(struct SNode*);

#endif

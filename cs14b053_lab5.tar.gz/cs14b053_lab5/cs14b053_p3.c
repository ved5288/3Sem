#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdbool.h>
#include"stack.h"

struct position
{
	int x;
	int y;
};

struct position FinalPosition(char* s)
{
	struct SNode* input=(struct SNode*)malloc(sizeof(struct SNode));
	struct SNode* output=(struct SNode*)malloc(sizeof(struct SNode));
	input = NULL;
	output = NULL;
	struct position current_location;
	current_location.x=0;
	current_location.y=0;
	if(strlen(s)==0)
		return current_location;
	int i,number;
	Push(&input,'*');
	for(i=strlen(s)-1;i>=0;i--)
	{
		Push(&input,s[i]);
	}
	
	while(Top(input)!='*')
	{
	
		if(Top(input)=='U')
		{
			current_location.y+=1;
			Push(&output,Pop(&input));
			continue;	
		}
	
		if(Top(input)=='D')
		{
			current_location.y-=1;
			Push(&output,Pop(&input));
			continue;	
		}
	
		if(Top(input)=='R')
		{
			current_location.x+=1;
			Push(&output,Pop(&input));	
			continue;
		}
	
		if(Top(input)=='L')
		{
			current_location.x-=1;
			Push(&output,Pop(&input));	
			continue;
		}
	
		if(Top(input)=='B')
		{
			number=0;
			Pop(&input);
			do		
			{
				number=number*10+(int)(Pop(&input)-'0');		
			}
			while(Top(input)-'0'>=0&&Top(input)-'0'<=9);
			
			for(i=0;i<number;i++)
			{
				if(isEmpty(output)==true)
					break;
				
				if(Top(output)=='U')
				{
					current_location.y-=1;
					Pop(&output);	
					continue;
				}
		
				if(Top(output)=='D')
				{
					current_location.y+=1;
					Pop(&output);	
					continue;				
				}
		
				if(Top(output)=='R')
				{
					current_location.x-=1;
					Pop(&output);	
					continue;
				}
	
				if(Top(output)=='L')
				{
					current_location.x+=1;
					Pop(&output);	
					continue;
				}
		
			}
		}
	}
return current_location;
}

int main()
{
	char s[1000];
	scanf("%s",s);
	printf("The final location is (%d,%d)\n",FinalPosition(s).x,FinalPosition(s).y);
return 0;
}


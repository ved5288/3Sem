#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdbool.h>
#include"stack.h"

void Push(struct SNode** top, char ch)
{
	struct SNode* current_stack = *top;
	// current_stack is the stack to work upon

	//create a SNode
	struct SNode* temp=(struct SNode*)malloc(sizeof(struct SNode));
	temp->data=ch;
	temp->next=current_stack;

	//reassign the value to the stack *top*
	*top=temp;
}

char Pop(struct SNode** top)
{
	//assumed that the Stack is not empty
	struct SNode* current_stack = *top;

	if(current_stack==NULL)
	{
		//printf("The Stack is empty\n");
		return 0;
	}

	char b;
	b=current_stack->data;
	struct SNode* temp;
	temp=current_stack;
	current_stack=current_stack->next;
	*top=current_stack;
	free(temp);
	return b;
}

char Top(struct SNode* top)
{
	
	if(top==NULL)
	{
		//printf("The stack is empty\n");
		return 0;
	}
	return top->data;
}

bool isEmpty(struct SNode* top)
{
	if(top==NULL) return true;
	return false;
}


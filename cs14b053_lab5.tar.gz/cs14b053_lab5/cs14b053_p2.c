#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdbool.h>
#include"stack.h"

bool isBalanceParanthesis(char*s)
{
	struct SNode* input=(struct SNode*)malloc(sizeof(struct SNode));
	struct SNode* output=(struct SNode*)malloc(sizeof(struct SNode));
	input = NULL;
	output = NULL;
	if(strlen(s)==0) 
		return true;
	if(strlen(s)%2!=0) 
		return false;
	int i;
	for(i=strlen(s)-1;i>=0;i--)
	{
		Push(&input,s[i]);
		//The input stack will now contain the input
	}
	for(i=0;i<strlen(s)/2;)
	{
		if(isEmpty(input)==true)
			return false;
		if(Top(input)=='}')
		{
			if(Top(output)!='{')
				return false;
			Pop(&input);
			Pop(&output);
			i++;	
		}
		if(Top(input)==')')
		{
			if(Top(output)!='(')
				return false;
			Pop(&input);
			Pop(&output);	
			i++;	
		}
		if(Top(input)==']')
		{
			if(Top(output)!='[')
				return false;
			Pop(&input);
			Pop(&output);	
			i++;	
		}
		if(Top(input)=='{'||Top(input)=='('||Top(input)=='[')
		{
			Push(&output,Pop(&input));
		}
	}
	return true;
}

int main()
{
	char s[1000];
	scanf("%s",s);
	if(isBalanceParanthesis(s)==true)
		printf("The paranthesis are balanced\n");
	else
		printf("The paranthesis are not balanced\n");
return 0;
}


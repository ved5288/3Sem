#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int AreTheyFriends(char* s1, char*s2)
{
	int a,b,p;
	a= strlen(s1);
	b=strlen(s2);
	
	if(a!=b)
		return 0;
	
	if(a%2==1)
	{
		if(strcmp(s1,s2)==0) 
			return 1;
		return 0;
	}

	char *s3,*s4,*s5,*s6;
	s3=(char*)malloc(sizeof(char)*(a/2+1));
	s4=(char*)malloc(sizeof(char)*(a/2+1));
	s5=(char*)malloc(sizeof(char)*(b/2+1));
	s6=(char*)malloc(sizeof(char)*(b/2+1));

	strncpy(s3,s1,a/2);
	strcpy(s4,&s1[a/2]);
	strncpy(s5,s2,b/2);
	strcpy(s6,&s2[b/2]);

	p=AreTheyFriends(s3,s5);
	if(p==1&&AreTheyFriends(s4,s6)==1)	//changed here
		return 1;
	p=AreTheyFriends(s3,s6);
	if(p==1&&AreTheyFriends(s4,s5)==1)	//changed here
		return 1;
	return 0;				//added this
	p=AreTheyFriends(s4,s5);
	if(p==1)
		return 1;
	p=AreTheyFriends(s4,s6);
	return p;
}

int main(int argc,char* argv[])
{
	FILE *ifp, *ofp;
	int t,i;
	char s1[1024],s2[1024];
	ifp = fopen(argv[1],"r");
	ofp = fopen(argv[2],"w");
	fscanf(ifp,"%d",&t);
	for(i=0;i<t;i++)
	{
		fscanf(ifp,"%s %s",s1,s2);
		fprintf(ofp,"%d\n",AreTheyFriends(s1,s2));
	}
return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
#include<string.h>



bool dict(char* s)
{
	int i;
	char* array[] = {"this","is","a","good","test","isag","be","broken","test","me","if","you","can","and","print","me","how","do","write","such","program"};
	for(i=0;i<21;i++)
		if(strcmp(s,array[i])==0)
			return true;
	return false;
	//returns true if s is a valid word
	//returns FAlSE is s is not a valid word.
}

int main(int argc, char* argv[])
{

	FILE *ifp,*ofp;
	ifp=fopen(argv[1],"r");
	ofp=fopen(argv[2],"w");

	int t,i,n,j,p,curr_value,q;

	fscanf(ifp,"%d",&t);
	for(p=0;p<t;p++)
	{
		char s[101];
		fscanf(ifp,"%s",s);
		n=strlen(s);
		int valid[n],curr_index;
		
		for(i=0;i<n;i++)
			valid[i]=0;

		for(i=0;i<n;i++)
		{
			char temp[i+2];

			strncpy(temp,s,i+1);
			temp[i+1]='\0';
			if(dict(temp)==true)
				valid[i]=1;
			
			else
			{
			
				for(j=0;j<i;j++)
				{
					char temp1[n-j-1];
					strncpy(temp1,&temp[j+1],n-j-1);
					temp1[n-j-1]='\0';
					if(valid[j]!=0)
						if(dict(temp1)==true)
							valid[i]=j;
				}	
			
			}	
		}
		

		if(valid[n-1]==0)
			fprintf(ofp,"Invalid String\n");
		else
		{
			curr_value=n-1;
			while(valid[curr_value]!=1)
			{
				q=valid[curr_value];
				valid[curr_value]=-1;
				curr_value=q;
			}
			valid[curr_value]=-1;
			for(i=0;i<n;i++)
				if(valid[i]!=-1)
					valid[i]=0;
		

			for(i=0;i<n;i++)
				if(valid[i]==-1)
					fprintf(ofp,"%c ",s[i]);
				else
					fprintf(ofp,"%c",s[i]);
			fprintf(ofp,"\n");
		}
	
	}

	
return 0;	
}

#include<stdio.h>

int sum(int* ptr1,int* ptr2){
int sum=0;
int* i;
if(ptr1<ptr2)
for(i=ptr1;i<=ptr2;i++)
sum+=*i;
else
for(i=ptr2;i<=ptr1;i++)
sum+=*i;

return sum;
}

int main()
{
return 0;
}


#include<stdio.h>
#include<string.h>
#include<stdlib.h>

struct student 
{
	char* name;
	int rollno;
	char* dept;
	struct student* next;
};

struct student* Slist;

void print()
{
	printf("\n");
	if(Slist==NULL)
	{
		printf("The linked list is empty\n");
		return;
	}

	struct student* temp = Slist;
	while(temp->next!=NULL)
	{
		printf("%s -- %d -- %s \n",temp->name,temp->rollno,temp->dept);
		temp=temp->next;
	}
	printf("%s -- %d -- %s \n", temp->name,temp->rollno,temp->dept);
}

void addAtBack(char* name,int rollno,char* dept)
{
	struct student* temp=(struct student*)malloc(sizeof(struct student));
	temp->name=(char*)malloc(sizeof(char)*strlen(name));
	strcpy(temp->name,name);
	temp->rollno=rollno;
	temp->dept=(char*)malloc(sizeof(char)*strlen(dept));
	strcpy(temp->dept,dept);
	temp->next=NULL;

	if(Slist==NULL)
	{
		Slist=temp;
		return;
	}
	
	struct student* temp1=Slist;
	while(temp1->next!=NULL)
	{
		temp1=temp1->next;
	}
	temp1->next=temp;
}

void addAtIndex(char* name,int rollno,char* dept,int k)
{
	struct student* temp=(struct student*)malloc(sizeof(struct student));
	temp->name=(char*)malloc(sizeof(char)*strlen(name));
	strcpy(temp->name,name);
	temp->rollno=rollno;
	temp->dept=(char*)malloc(sizeof(char)*strlen(dept));
	strcpy(temp->dept,dept);
	temp->next=NULL;

	//printf("%s -- %d -- %s \n", temp->name,temp->rollno,temp->dept);

	if(Slist==NULL)
	{
		Slist=temp;
		return;
	}

	struct student* temp1 = Slist;
	
	//currently temp1 is pointing at the first node
	int CL=1;
	if(k==1)
	{
		temp->next=temp1;
		temp1=temp;
	}
	while(temp1->next!=NULL&&CL<k-1)
	{
		temp1=temp1->next;
		CL++;
	}
	temp->next=temp1->next;
	temp1->next=temp;
}

int delete(int rollno)
{
	struct student* temp = Slist;
	
	if(temp==NULL)
	return -1;
	while(temp->next!=NULL)
	{
		if(temp->rollno==rollno)
		{
			struct student* temp1;
			temp1=temp;
			struct student* temp2=Slist;
			while(temp2->next!=temp1)
				temp2=temp->next;
			temp2->next=temp1->next;
			free(temp1);
			return 1;
		}
		temp=temp->next;		
	}	
return -1;
}

int getRollno(int k)
{
	int CL=1;
	if(k==0)
		 return -1;
	struct student* temp=Slist;
	if(Slist==NULL) 
		return -1;
	while(temp->next!=NULL)
	{
		if(CL==k) 
			return temp->rollno;
		temp=temp->next;
		CL++;
	}
	if(CL==k) 
		return temp->rollno;
return -1;
}

int getDept(char* dept)
{
	if(Slist==NULL)
		return 0;
	int count=0;
	struct student* temp=Slist;
	while(temp->next!=NULL)
	{
		if(strcmp(temp->dept,dept)==0)
			count++;
		temp=temp->next;	
	}
	if(strcmp(temp->dept,dept)==0)
			count++;	
return count;
}

int main()
{
	Slist=NULL;
	print();
	addAtIndex("Ved",4,"BT",4);
	print();
	addAtBack("Vedant",1,"CSE");
	print();
	addAtBack("Somani",2,"Computer Science and Engineering");
	print();
	addAtIndex("Rahul",3,"CSE",2);
	print();
	printf("\n%d\n",delete(5));
	print();
	printf("\n%d\n",getRollno(0));
	printf("\n%d\n",getRollno(4));
	printf("\n%d\n",getRollno(7));
	printf("\n%d\n",getDept(""));
return 0;	
}

#include<stdio.h>

struct point{
int vertex;
float x;
float y;
};

struct point input[1000];

int find_cross_product(int vertex,int n){
int a,b;
float big_vector_y,big_vector_x,small_vector_y,small_vector_x,cross_product;
if(vertex==1) a=n;
else a=vertex-1;
if(vertex==n) b=1;
else b=vertex+1;
big_vector_y=input[b-1].y-input[vertex-1].y;
big_vector_x=input[b-1].x-input[vertex-1].x;
small_vector_y=input[a-1].y-input[vertex-1].y;
small_vector_x=input[a-1].x-input[vertex-1].x;
cross_product = (big_vector_y*small_vector_x)-(big_vector_x*small_vector_y);

if(cross_product<0) return -1;
else if(cross_product>0) return 1;
return 0;
}


int main() {
int n;
scanf("%d",&n);
int i,a,p;
int B[n];

for(i=0;i<n;i++)
	{	
		scanf("%d",&a);
		input[a-1].vertex=a;
		B[i]=a;
		scanf("%f",&input[a-1].x);
		scanf("%f",&input[a-1].y);	//stores the input
	}
float greatest_x;
int vertex_number,flag=0;
greatest_x=input[0].x;

vertex_number = 1;
for(i=1;i<n;i++)
if(input[i].x>greatest_x)
{
greatest_x=input[i].x;
vertex_number=i+1;		//vertex_number so obtained will definitely be concave, because it is on the right most part of the figure
}

//check for reference value
p=find_cross_product(vertex_number,n);
while(p==0&&vertex_number<=n)
{
p=find_cross_product(vertex_number+1,n);
}
if(p==0) 
{
	printf("-1\n");
	return 0;
}
//now for whatever vertices find_cross_product is same as reference, they are all concave
for(i=0;i<n;i++)
if(find_cross_product(B[i],n)!=p)
{
	printf("%d ",B[i]);
	flag=1;
}	
if(flag==0)
printf("0");
printf("\n");
return 0;
}

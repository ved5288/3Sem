bool dict(char* s){
	char* dictionary[] = {"this","is","a","good","test","ago","me","if","you","can","and","how","do","write","such","a","program","print","some","permit","control","over","different",
"functions","the","airport","moving","away","from","dependence","bad","code","poetry","go","i","am","poet","once","upon","time","there","hermit","the", "bowler", "delivers", "ball", "to", "batsman", "who", "attempts", "to", "hit", "ball", "with", "his", "bat", "away", "from","fielders", "so", "he", "can", "run", "to","other", "end", "of", "pitch", "and", "score","run", "each", "batsman", "continues", "batting", "until", "he","is", "out","earliest", "written", "evidence", "of", "game", "cricket", "may", "date", "back", "to", "france", "in", "letter", "written", "to", "king", "louis", "XI","as", "was", "reported", "to", "press", "not", "only", "are","buses", "somewhat", "inconvenient", "and", "uncomfortable"};
	
 int size = sizeof(dictionary)/sizeof(dictionary[0]);
   
int i;
 for (i = 0; i < size; i++)
	if(strcmp(s,dictionary[i])==0){
		return true;	
	}
	
	
	return false;
}



#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdint.h>
struct student{
	char name[100],dept[50];
	int rollno;
	struct student *next;
};
struct student *Slist;

void addAtBack(char* name,int rollno,char* dept)
{
    struct student *current;
    current=(struct student*)malloc(sizeof(struct student));
    current=Slist;
    if(current!=0)
        {
            while(current->next!=0)
            {
                current=current->next;
            }
            current->next=(struct student*)malloc(sizeof(struct student));
            current=current->next;
            strcpy(current->name,name);
            strcpy(current->dept,dept);
            current->rollno=rollno;
            current->next=0;
        }
}
void addAtIndex(char *name,int rollno,char *dept,int k)
{
	int i=1;
	struct student *current=(struct student*)malloc(sizeof(struct student));
	struct student *temp=(struct student*)malloc(sizeof(struct student));
	current=Slist;
	strcpy(temp->name,name);
	strcpy(temp->dept,dept);
	temp->rollno=rollno;
	temp->next=0;
	if(k==1)
        {
            addAtIndex(Slist->name,Slist->rollno,Slist->dept,2);
            Slist=temp;
        }
    if(current!=0)
        {
            while(i<k-1 && current->next!=0)
            {
                current=current->next;
                i++;
            }
            if(current->next==0)
                addAtBack(temp->name,temp->rollno,temp->dept);
            else
            {
                temp->next=current->next;
                current->next=temp;
            }
        }
}

int delete(int rollno)
{
	struct student *current;
	current=(struct student*)malloc(sizeof(struct student));
	current=Slist;
	struct student *temp;
	temp=(struct student*)malloc(sizeof(struct student));
	if(Slist->rollno==rollno){
	Slist=Slist->next;
	free(Slist);
	return 1;}
	if(current!=0){
		while(current->next!=0){
			temp=current->next;
			if(temp->rollno==rollno){
				current->next=temp->next;
				return 1;
			}
			current=current->next;
		}
	}
	return -1;
}

int getRollno(int k){
	struct student *current;
	current=(struct student*)malloc(sizeof(struct student));
	current=Slist;
	int i=0;
	if(current!=0){
		while(i<k-1){
			current=current->next;
			i++;
		}
	}
	return current->rollno;
}

int getDept(char *dept){
	struct student *current;
	current=(struct student*)malloc(sizeof(struct student));
	current=Slist;
	int i=0;
	if(current!=0){
		while(current!=0){
			if(strcmp(current->dept,dept)==0){
				i++;
			}
			current=current->next;
		}
	}
	return i;
}

int main()
{
	int i,t;
	char c;
	struct student *temp;
	Slist=(struct student*)malloc(sizeof(struct student));
	printf("Enter the name : ");
	gets(Slist->name);
	printf("Enter the roll no. : ");
	scanf("%d",&t);
	Slist->rollno=t;
	printf("Enter the dept : ");
	getchar();
	gets(Slist->dept);
	Slist->next=NULL;
	temp=Slist;
	printf("Would you like to make another entry(y/n) : ");
	scanf("%c",&c);
	getchar();
	while(c=='y')
	{
		temp->next=(struct student*)malloc(sizeof(struct student));
		temp=temp->next;
		printf("Enter the name : ");
		gets(temp->name);
		printf("Enter the roll no. : ");
		scanf("%d",&t);
		temp->rollno=t;
		printf("Enter the dept : ");
		getchar();
		gets(temp->dept);
		temp->next=NULL;
		printf("Would you like to make another entry(y/n) : ");
		scanf("%c",&c);
		getchar();
	}
	temp=Slist;
	while(temp!=NULL)
	{
		printf("%s\t%d\t%s\n",temp->name,temp->rollno,temp->dept);
		temp=temp->next;
	}
	printf("%d\n",getRollno(4));
	printf("%d\n",getDept("blah"));
	return 0;
}



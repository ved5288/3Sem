#include<stdio.h>
int main()
       {
    	    int ar[10]={0,1,2,3,4,5,6,7,8,9,10};
	    int p;
	    int *ptr1,*ptr2;
	     p=sum(&ar[4],&ar[8]);
	     printf("%d\n",p);
             return 0;
       }

int sum(int* ptr1,int* ptr2)
       {
        int sum=0;
        int i;
        if(ptr1<ptr2)
         {
          for(i=0;i<=(ptr2-ptr1);i++)
           {
             sum = sum + *(ptr1+i);
           }
         }
        else if(ptr1>ptr2)
          {
            for(i=0;i<=(ptr1-ptr2);i++)
              {
               sum = sum + *(ptr2+i);
              }
          }
      return sum;
    }




#include<stdio.h>

int main()
{
    int num,i,k=0,count=0,p;
    scanf("%d\n",&num);
    float l,x1[num],y1[num],cross[num];
    struct point
    {
        float x,y;
        int n;
    }coord[num];
    for(i=0;i<num;i++)
    {
        scanf("%d %f %f",&coord[i].n,&coord[i].x,&coord[i].y);
    }
    l=coord[0].x;
    for(i=1;i<num;i++)
    {
        if(coord[i].x<l)
        {
            l=coord[i].x;
        }
    }
    for(i=1;i<=num;i++)
    {
        while(coord[k].n !=i && k<num)
        {
            k++;
        }
        x1[i-1]=coord[k].x;
        y1[i-1]=coord[k].y;
        k=0;
    }
    for(i=0;i<num;i++)
    {
        p=coord[i].n;
        if(coord[i].n==1)
        {
            cross[i]=((x1[0]-x1[num-1])*(y1[1]-y1[0]))-((y1[0]-y1[num-1])*(x1[1]-x1[0]));
        }
        else if(coord[i].n==num)
        {
            cross[i]=((x1[num-1]-x1[num-2])*(y1[0]-y1[num-1]))-((y1[num-1]-y1[num-2])*(x1[0]-x1[num-1]));
        }
        else
        {
            cross[i]=((x1[p-1]-x1[p-1-1])*(y1[p-1+1]-y1[p-1])-((y1[p-1]-y1[p-1-1])*(x1[p-1+1]-x1[p-1])));
        }

        if(coord[i].x==l)
        {
            l=cross[i];
        }
    }
    for(i=0;i<num;i++)
    {
        if(l*cross[i]<0)
        {
            printf("%d ",coord[i].n);
            count++;
        }
    }
    if(count==0)
    {
        printf("0");
    }
    return 0;
}

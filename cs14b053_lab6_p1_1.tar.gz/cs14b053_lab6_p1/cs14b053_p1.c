#include<stdio.h>

// n is the number of test cases
// A[n] is the array of the number of elements in each test case

int greatest_number(int* A,int front_index,int back_index)
{
	if(front_index==back_index)
		return A[front_index];

	if(back_index==front_index+1)
		{
			if(A[front_index]>A[back_index]) 
				return A[front_index];
			return A[back_index];
		}
	
	int middle;
	middle = front_index+(-front_index+back_index)/2; 	// changed here
	
	if(A[middle]>A[middle+1]&&A[middle]>A[middle-1])
		return A[middle];	
	
	if(A[middle]<A[middle+1])
		return greatest_number(&A[0],middle+1,back_index);
	else if(A[middle]<A[middle-1])
		return greatest_number(&A[0],front_index,middle-1);
	else if(A[middle-1]==A[middle+1])
		{
			int a,b;
			a=greatest_number(&A[0],front_index,middle-1);
			b=greatest_number(&A[0],middle+1,back_index);
			if(a>b)
				return a;
			return b;
		}
	else if(A[middle]==A[middle-1])
		return greatest_number(&A[0],front_index,middle-1);
	else if (A[middle]==A[middle+1])
		return greatest_number(&A[0],middle+1,back_index);
return -1;
}

int main(int argc,char *argv[])
{
	FILE* ifp, *ofp;
	int n,p,j,i;
	ifp=fopen(argv[1],"r");
	ofp=fopen(argv[2],"w");
	fscanf(ifp,"%d",&n);
	for(i=0;i<n;i++)
	{
		fscanf(ifp,"%d",&p);
		int A[p];
		for(j=0;j<p;j++)
		{
			fscanf(ifp,"%d",&A[j]);
			printf("%d\n",A[j]);
		}
		fprintf(ofp,"%d\n",greatest_number(&A[0],0,p-1));
	}
	fclose(ifp);
	fclose(ofp);
return 0;
}

